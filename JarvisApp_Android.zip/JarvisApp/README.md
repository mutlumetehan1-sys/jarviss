# 🤖 JARVIS Android Uygulaması

Iron Man'deki JARVIS'ten ilham alınan, **öz öğrenme** becerisine sahip Android AI asistanı.

## ✨ Özellikler

### 🧠 Öz Öğrenme Sistemi
- **Kullanıcı Tanıma**: İsim, meslek ve tercihleri otomatik öğrenir
- **Bağlam Hafızası**: Önceki konuşmalardan bağlam korur
- **Dinamik Prompt**: Her konuşmada öğrenilenleri sisteme entegre eder
- **Örüntü Tanıma**: Sık sorulan konuları tespit eder
- **Hata Öğrenme**: Kullanıcı düzeltmelerinden öğrenir
- **Teknoloji Tespiti**: Kullandığı dil/framework'leri hatırlar

### 💬 4 Uzman Modu
| Mod | Açıklama |
|-----|----------|
| 💬 SOHBET | Genel konuşma asistanı |
| 💻 KOD | Yazılım geliştirme & hata ayıklama |
| 🏗️ PROJE | Mimari tasarım & proje planlama |
| 🔍 ANALİZ | Derin analiz & içgörü |

### 🎤 Ses Özellikleri
- **Türkçe Ses Tanıma** (Speech-to-Text)
- **Türkçe Sesli Yanıt** (Text-to-Speech)
- Sesli komut ile tam kontrol

### 🎨 JARVIS UI
- Siyan/mavi renk paleti, karanlık tema
- Animasyonlu thinking göstergesi
- Kod blokları syntax highlight
- Canlı ses dalga animasyonu

---

## 🚀 Kurulum

### Gereksinimler
- Android Studio Hedgehog (2023.1.1) veya üzeri
- Android SDK 26+ (Android 8.0)
- Anthropic API anahtarı (`sk-ant-...`)

### Adımlar

1. **Projeyi aç:**
   ```
   Android Studio → Open → JarvisApp klasörü
   ```

2. **Gradle sync:**
   ```
   File → Sync Project with Gradle Files
   ```

3. **Cihaza yükle:**
   ```
   Run → Run 'app' (veya Shift+F10)
   ```

4. **API anahtarını gir:**
   - Uygulama açılınca API anahtarı ekranı gelir
   - `sk-ant-api...` formatında Anthropic anahtarınızı girin
   - Anahtar güvenli şekilde cihazda saklanır

---

## 📁 Proje Yapısı

```
JarvisApp/
├── app/src/main/java/com/jarvis/app/
│   ├── MainActivity.kt              # Ana aktivite
│   ├── api/
│   │   ├── AnthropicModels.kt       # API veri modelleri
│   │   └── AnthropicService.kt      # Retrofit API servisi
│   ├── database/
│   │   ├── Entities.kt              # Room entity'leri
│   │   ├── Daos.kt                  # Database erişim nesneleri
│   │   └── JarvisDatabase.kt        # Room veritabanı
│   ├── learning/
│   │   └── LearningEngine.kt        # 🧠 ÖZ ÖĞRENME MOTORU
│   ├── speech/
│   │   └── SpeechRecognitionManager.kt  # Ses tanıma
│   ├── tts/
│   │   └── JarvisTTS.kt             # Text-to-Speech
│   ├── ui/
│   │   ├── SetupScreen.kt           # API kurulum ekranı
│   │   ├── ChatScreen.kt            # Ana sohbet ekranı
│   │   └── theme/Theme.kt           # JARVIS renk teması
│   └── viewmodel/
│       └── JarvisViewModel.kt       # Ana iş mantığı
```

---

## 🧠 Öz Öğrenme Nasıl Çalışır?

```
Kullanıcı Mesajı
      ↓
LearningEngine.processUserMessage()
      ↓
┌─────────────────────────────────────┐
│  1. İsim/Meslek Extraction          │
│  2. Teknoloji Tercihi Algılama      │
│  3. Sorgu Örüntüsü Takibi          │
│  4. Cevap Stili Öğrenme            │
└─────────────────────────────────────┘
      ↓
buildDynamicSystemPrompt()
      ↓
┌─────────────────────────────────────┐
│  Base Prompt + Öğrenilen Bilgiler   │
│  + Son Konuşma Bağlamı             │
│  + Sık Kullanılan Konular          │
│  + Düzeltmeler                     │
└─────────────────────────────────────┘
      ↓
Anthropic Claude API
      ↓
Kişiselleştirilmiş Cevap
```

---

## 🗄️ Veritabanı Şeması

| Tablo | Açıklama |
|-------|----------|
| `conversations` | Tüm konuşma geçmişi |
| `user_preferences` | Kullanıcı tercihleri (isim, meslek, stil) |
| `learned_facts` | Öğrenilen gerçekler ve bilgiler |
| `query_patterns` | Sık sorulan konu kalıpları |
| `corrections` | Kullanıcı tarafından yapılan düzeltmeler |

---

## 📱 Ekran Görüntüleri

```
┌─────────────────────┐
│  J.A.R.V.I.S  [🔊] │  ← Header
├─────────────────────┤
│ SOHBET KOD PROJE AN │  ← Mod sekmeleri
├─────────────────────┤
│                     │
│  [JARVIS]           │
│  Merhaba. Ben       │
│  JARVIS...          │
│                     │
│          [SİZ]      │
│     Merhaba Jarvis  │
│                     │
├─────────────────────┤
│ [🎤] [Mesaj yaz...] [➤] │  ← Giriş alanı
└─────────────────────┘
```

---

## ⚙️ Teknik Detaylar

- **Dil**: Kotlin
- **UI**: Jetpack Compose
- **Veritabanı**: Room (SQLite)
- **Network**: Retrofit + OkHttp
- **AI**: Anthropic Claude Sonnet
- **Mimari**: MVVM + Repository Pattern
- **Async**: Kotlin Coroutines + Flow
- **Depolama**: DataStore Preferences

---

## 🔒 Gizlilik

- API anahtarı yalnızca cihazda (DataStore) saklanır
- Konuşma geçmişi yalnızca yerel veritabanında tutulur
- İnternet bağlantısı yalnızca Anthropic API için kullanılır

---

*"J.A.R.V.I.S — Just A Rather Very Intelligent System"*