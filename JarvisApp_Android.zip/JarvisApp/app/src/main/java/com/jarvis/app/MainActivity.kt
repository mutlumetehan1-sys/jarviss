package com.jarvis.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.jarvis.app.ui.ChatScreen
import com.jarvis.app.ui.SetupScreen
import com.jarvis.app.ui.theme.JarvisTheme
import com.jarvis.app.viewmodel.JarvisViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()

    // Mikrofon izin launcher'ı
    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            // İzin reddedildi - TTS çalışmaya devam eder
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mikrofon iznini iste
        requestMicPermission()

        setContent {
            JarvisTheme {
                JarvisApp(viewModel = viewModel)
            }
        }
    }

    private fun requestMicPermission() {
        when {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED -> {
                // İzin var
            }
            else -> {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }
}

@Composable
fun JarvisApp(viewModel: JarvisViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    AnimatedContent(
        targetState = uiState.isSetupDone,
        transitionSpec = {
            fadeIn(animationSpec = tween(600)) togetherWith
                    fadeOut(animationSpec = tween(600))
        },
        label = "screen_transition"
    ) { isSetupDone ->
        if (isSetupDone) {
            ChatScreen(
                uiState = uiState,
                onSend = { viewModel.sendMessage() },
                onInputChange = { viewModel.updateInputText(it) },
                onModeChange = { viewModel.setMode(it) },
                onMicToggle = { viewModel.toggleMic() },
                onTtsToggle = { viewModel.toggleTts() },
                onClearHistory = { viewModel.clearHistory() },
                onToggleLearning = { viewModel.toggleLearningPanel() },
                onResetApi = { viewModel.resetApiKey() },
                isSpeechAvailable = viewModel.isSpeechAvailable()
            )
        } else {
            SetupScreen(
                onInit = { apiKey -> viewModel.initJarvis(apiKey) },
                errorMessage = uiState.errorMessage
            )
        }
    }
}