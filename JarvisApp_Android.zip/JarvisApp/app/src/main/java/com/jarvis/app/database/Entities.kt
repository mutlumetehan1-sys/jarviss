package com.jarvis.app.database

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Konuşma geçmişi - JARVIS her konuşmayı hatırlar
 */
@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: String,
    val role: String,           // "user" veya "assistant"
    val content: String,
    val mode: String,           // chat, code, project, analyze
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Kullanıcı tercihleri - JARVIS kullanıcıyı öğrenir
 */
@Entity(tableName = "user_preferences")
data class UserPreferenceEntity(
    @PrimaryKey val key: String,
    val value: String,
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Öğrenilen bilgiler - JARVIS kendi notlarını tutar
 */
@Entity(tableName = "learned_facts")
data class LearnedFactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,       // "user_name", "topic", "preference", "correction"
    val fact: String,
    val confidence: Float = 1.0f,
    val usageCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Sık sorulan sorular / kalıplar - JARVIS örüntüleri öğrenir
 */
@Entity(tableName = "query_patterns")
data class QueryPatternEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pattern: String,
    val mode: String,
    val frequency: Int = 1,
    val lastUsed: Long = System.currentTimeMillis()
)

/**
 * Hata düzeltmeleri - Kullanıcı yanlış cevabı düzeltirse JARVIS öğrenir
 */
@Entity(tableName = "corrections")
data class CorrectionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val originalQuery: String,
    val wrongResponse: String,
    val correctedResponse: String,
    val timestamp: Long = System.currentTimeMillis()
)