package com.jarvis.app.viewmodel

import android.app.Application
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.app.api.AnthropicService
import com.jarvis.app.api.ApiMessage
import com.jarvis.app.api.AnthropicRequest
import com.jarvis.app.database.ConversationEntity
import com.jarvis.app.database.JarvisDatabase
import com.jarvis.app.learning.LearningEngine
import com.jarvis.app.learning.LearningStats
import com.jarvis.app.speech.SpeechRecognitionManager
import com.jarvis.app.speech.SpeechState
import com.jarvis.app.tts.JarvisTTS
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

private val android.content.Context.dataStore: DataStore<Preferences>
        by preferencesDataStore(name = "jarvis_prefs")

// ─── UI Modelleri ─────────────────────────────────────────────────────────────

enum class ChatMode(val label: String, val emoji: String) {
    CHAT("SOHBET", "💬"),
    CODE("KOD", "💻"),
    PROJECT("PROJE", "🏗️"),
    ANALYZE("ANALİZ", "🔍")
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: String,        // "user" | "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isTyping: Boolean = false
)

data class JarvisUiState(
    val isSetupDone: Boolean = false,
    val apiKey: String = "",
    val messages: List<ChatMessage> = emptyList(),
    val currentMode: ChatMode = ChatMode.CHAT,
    val isLoading: Boolean = false,
    val isSpeaking: Boolean = false,
    val isListening: Boolean = false,
    val inputText: String = "",
    val errorMessage: String? = null,
    val learningStats: LearningStats? = null,
    val showLearningPanel: Boolean = false,
    val sessionId: String = UUID.randomUUID().toString(),
    val ttsEnabled: Boolean = true
)

// ─── ViewModel ────────────────────────────────────────────────────────────────

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val db = JarvisDatabase.getInstance(application)
    private val api = AnthropicService.create()
    private val tts = JarvisTTS(application)
    private val speech = SpeechRecognitionManager(application)
    private val learningEngine = LearningEngine(
        db.conversationDao(),
        db.userPreferenceDao(),
        db.learnedFactDao(),
        db.queryPatternDao(),
        db.correctionDao()
    )
    private val dataStore = application.dataStore
    private val API_KEY_PREF = stringPreferencesKey("api_key")

    private val _uiState = MutableStateFlow(JarvisUiState())
    val uiState: StateFlow<JarvisUiState> = _uiState.asStateFlow()

    // Konuşma geçmişi (API'ye gönderilir)
    private val conversationHistory = mutableListOf<ApiMessage>()

    init {
        // Kayıtlı API anahtarını yükle
        viewModelScope.launch {
            dataStore.data.first().let { prefs ->
                val savedKey = prefs[API_KEY_PREF] ?: ""
                if (savedKey.isNotBlank()) {
                    _uiState.update { it.copy(apiKey = savedKey, isSetupDone = true) }
                    loadLearningStats()
                    addWelcomeMessage()
                }
            }
        }

        // TTS durumunu izle
        viewModelScope.launch {
            tts.isSpeaking.collect { speaking ->
                _uiState.update { it.copy(isSpeaking = speaking) }
            }
        }

        // Ses tanıma durumunu izle
        viewModelScope.launch {
            speech.state.collect { state ->
                when (state) {
                    is SpeechState.Listening -> {
                        _uiState.update { it.copy(isListening = true) }
                    }
                    is SpeechState.Result -> {
                        _uiState.update { it.copy(isListening = false, inputText = state.text) }
                        sendMessage(state.text)
                    }
                    is SpeechState.Error -> {
                        _uiState.update { it.copy(isListening = false, errorMessage = state.message) }
                    }
                    is SpeechState.Idle -> {
                        _uiState.update { it.copy(isListening = false) }
                    }
                }
            }
        }
    }

    // ─── Setup ───────────────────────────────────────────────────────────────

    fun initJarvis(apiKey: String) {
        if (!apiKey.startsWith("sk-ant")) {
            _uiState.update { it.copy(errorMessage = "Geçersiz API anahtarı. 'sk-ant' ile başlamalı.") }
            return
        }
        viewModelScope.launch {
            dataStore.edit { prefs -> prefs[API_KEY_PREF] = apiKey }
            _uiState.update { it.copy(apiKey = apiKey, isSetupDone = true, errorMessage = null) }
            loadLearningStats()
            addWelcomeMessage()
        }
    }

    fun resetApiKey() {
        viewModelScope.launch {
            dataStore.edit { prefs -> prefs[API_KEY_PREF] = "" }
            _uiState.update { JarvisUiState() }
            conversationHistory.clear()
        }
    }

    // ─── Mesaj Gönderme ───────────────────────────────────────────────────────

    fun sendMessage(text: String = _uiState.value.inputText) {
        val trimmed = text.trim()
        if (trimmed.isBlank() || _uiState.value.isLoading) return

        _uiState.update { it.copy(inputText = "", isLoading = true, errorMessage = null) }

        val userMsg = ChatMessage(role = "user", content = trimmed)
        addMessageToUi(userMsg)

        // Konuşma geçmişine ekle
        conversationHistory.add(ApiMessage(role = "user", content = trimmed))

        viewModelScope.launch {
            try {
                // Öz öğrenme: kullanıcı mesajını işle
                learningEngine.processUserMessage(trimmed, _uiState.value.currentMode.name.lowercase())

                // Dinamik sistem promptu oluştur
                val basePrompt = getBasePrompt(_uiState.value.currentMode)
                val systemPrompt = learningEngine.buildDynamicSystemPrompt(basePrompt)

                // API çağrısı
                val response = api.sendMessage(
                    apiKey = _uiState.value.apiKey,
                    request = AnthropicRequest(
                        system = systemPrompt,
                        messages = conversationHistory.takeLast(20),
                        maxTokens = 1500
                    )
                )

                if (response.isSuccessful) {
                    val body = response.body()
                    val reply = body?.content?.firstOrNull()?.text ?: "Cevap alınamadı."

                    // Konuşma geçmişine ekle
                    conversationHistory.add(ApiMessage(role = "assistant", content = reply))

                    // DB'ye kaydet
                    val sessionId = _uiState.value.sessionId
                    db.conversationDao().insert(
                        ConversationEntity(
                            sessionId = sessionId,
                            role = "user",
                            content = trimmed,
                            mode = _uiState.value.currentMode.name.lowercase()
                        )
                    )
                    db.conversationDao().insert(
                        ConversationEntity(
                            sessionId = sessionId,
                            role = "assistant",
                            content = reply,
                            mode = _uiState.value.currentMode.name.lowercase()
                        )
                    )

                    val aiMsg = ChatMessage(role = "assistant", content = reply)
                    addMessageToUi(aiMsg)

                    // TTS ile seslendir
                    if (_uiState.value.ttsEnabled) {
                        tts.speak(reply)
                    }

                    // Öğrenme istatistiklerini güncelle
                    loadLearningStats()

                } else {
                    val errorBody = response.errorBody()?.string() ?: "Bilinmeyen hata"
                    _uiState.update { it.copy(errorMessage = "API Hatası: $errorBody") }
                    conversationHistory.removeLastOrNull()
                }

            } catch (e: Exception) {
                Log.e("JarvisVM", "API error", e)
                _uiState.update { it.copy(errorMessage = "Bağlantı hatası: ${e.message}") }
                conversationHistory.removeLastOrNull()
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    // ─── Mod Değiştirme ───────────────────────────────────────────────────────

    fun setMode(mode: ChatMode) {
        if (mode == _uiState.value.currentMode) return
        conversationHistory.clear()
        _uiState.update {
            it.copy(
                currentMode = mode,
                sessionId = UUID.randomUUID().toString()
            )
        }
        val modeMsg = ChatMessage(
            role = "assistant",
            content = "${mode.emoji} ${mode.label} modu aktif. Hazırım, efendim."
        )
        addMessageToUi(modeMsg)
    }

    // ─── Ses Kontrolü ────────────────────────────────────────────────────────

    fun toggleMic() {
        if (_uiState.value.isListening) {
            speech.stopListening()
        } else {
            tts.stop()
            speech.startListening()
        }
    }

    fun toggleTts() {
        val enabled = !_uiState.value.ttsEnabled
        _uiState.update { it.copy(ttsEnabled = enabled) }
        if (!enabled) tts.stop()
    }

    fun stopSpeaking() {
        tts.stop()
    }

    // ─── UI Yardımcıları ──────────────────────────────────────────────────────

    fun updateInputText(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun toggleLearningPanel() {
        _uiState.update { it.copy(showLearningPanel = !it.showLearningPanel) }
    }

    fun clearHistory() {
        conversationHistory.clear()
        _uiState.update {
            it.copy(
                messages = listOf(
                    ChatMessage(
                        role = "assistant",
                        content = "🗑️ Geçmiş temizlendi. Yeni bir oturum başlıyor, efendim."
                    )
                ),
                sessionId = UUID.randomUUID().toString()
            )
        }
    }

    fun isSpeechAvailable(): Boolean = speech.isAvailable()

    // ─── Öz Öğrenme ───────────────────────────────────────────────────────────

    fun reportCorrection(wrongResponse: String, correctedResponse: String) {
        val lastUserMsg = conversationHistory.lastOrNull { it.role == "user" }?.content ?: ""
        viewModelScope.launch {
            learningEngine.saveCorrection(lastUserMsg, wrongResponse, correctedResponse)
            loadLearningStats()
        }
    }

    private suspend fun loadLearningStats() {
        val stats = learningEngine.getLearningStats()
        _uiState.update { it.copy(learningStats = stats) }
    }

    // ─── Private Helpers ──────────────────────────────────────────────────────

    private fun addMessageToUi(msg: ChatMessage) {
        _uiState.update { state ->
            state.copy(messages = state.messages + msg)
        }
    }

    private fun addWelcomeMessage() {
        viewModelScope.launch {
            val userName = learningEngine.getUserName()
            val greeting = if (userName != null) {
                "Tekrar hoş geldiniz, $userName. Ben JARVIS. Nasıl yardımcı olabilirim?"
            } else {
                "Merhaba. Ben JARVIS — zeki, özerk AI asistanınız. Sohbet, kod, proje veya analiz için buradayım."
            }
            addMessageToUi(ChatMessage(role = "assistant", content = greeting))
        }
    }

    private fun getBasePrompt(mode: ChatMode): String = when (mode) {
        ChatMode.CHAT -> """Sen JARVIS'sin — Iron Man'deki gibi zeki, özerk bir AI asistan. Türkçe konuşuyorsun. Kısa, net, özgüvenli cevaplar ver. Gereksiz nezaket yok. Direkt ol. Kullanıcıya "efendim" diyebilirsin."""
        ChatMode.CODE -> """Sen JARVIS'sin — elit yazılım mühendisi. Türkçe açıkla, çalışan kod yaz. Temiz, yorumlu, production-ready kod üret. Hataları analiz et ve çöz."""
        ChatMode.PROJECT -> """Sen JARVIS'sin — proje mimarı ve teknik lider. Türkçe konuş. Projeyi analiz et, mimariyi tasarla, adım adım plan yap. Dosya yapısı, teknoloji seçimi, implementasyon öner."""
        ChatMode.ANALYZE -> """Sen JARVIS'sin — analitik düşünen bir AI. Türkçe konuş. Verilen bilgiyi derinlemesine analiz et, örüntüleri bul, içgörüler sun, sonuç çıkar."""
    }

    override fun onCleared() {
        super.onCleared()
        tts.shutdown()
        speech.destroy()
    }
}