package com.jarvis.app.learning

import com.jarvis.app.database.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * JARVIS Öz Öğrenme Motoru
 *
 * Bu motor:
 * 1. Kullanıcının kim olduğunu öğrenir (isim, meslek, tercihler)
 * 2. Sık sorulan soruları/konuları hatırlar
 * 3. Hangi modun ne zaman kullanıldığını analiz eder
 * 4. Hata düzeltmelerinden öğrenir
 * 5. API'ye gönderilecek dinamik sistem promptunu üretir
 */
class LearningEngine(
    private val conversationDao: ConversationDao,
    private val userPreferenceDao: UserPreferenceDao,
    private val learnedFactDao: LearnedFactDao,
    private val queryPatternDao: QueryPatternDao,
    private val correctionDao: CorrectionDao
) {

    // ─── Kullanıcıdan bilgi çıkarma ───────────────────────────────────────────

    suspend fun processUserMessage(message: String, mode: String) {
        withContext(Dispatchers.IO) {
            extractUserInfo(message)
            trackQueryPattern(message, mode)
        }
    }

    private suspend fun extractUserInfo(message: String) {
        val lower = message.lowercase()

        // İsim öğrenme
        val namePatterns = listOf(
            Regex("benim adım (.+)", RegexOption.IGNORE_CASE),
            Regex("ben ([A-Z][a-z]+)'?[iy]?ım", RegexOption.IGNORE_CASE),
            Regex("ismim (.+)", RegexOption.IGNORE_CASE),
            Regex("adım (.+)", RegexOption.IGNORE_CASE)
        )
        namePatterns.forEach { pattern ->
            pattern.find(message)?.let { match ->
                val name = match.groupValues[1].trim().split(" ").first()
                if (name.length in 2..20) {
                    saveFact("user_name", "Kullanıcının adı: $name", 1.0f)
                    savePreference("user_name", name)
                }
            }
        }

        // Meslek / uzmanlık
        val professionKeywords = mapOf(
            "yazılımcı" to "Yazılım geliştirici",
            "developer" to "Yazılım geliştirici",
            "mühendis" to "Mühendis",
            "tasarımcı" to "Tasarımcı",
            "öğrenci" to "Öğrenci",
            "öğretmen" to "Öğretmen",
            "doktor" to "Doktor",
            "mimar" to "Mimar",
            "veri bilimci" to "Veri Bilimci",
            "data scientist" to "Veri Bilimci"
        )
        professionKeywords.forEach { (keyword, label) ->
            if (lower.contains(keyword)) {
                saveFact("profession", "Kullanıcının mesleği: $label", 0.8f)
                savePreference("profession", label)
            }
        }

        // Dil/teknoloji tercihleri
        val techKeywords = listOf(
            "kotlin", "java", "python", "javascript", "typescript",
            "react", "android", "ios", "flutter", "vue", "angular",
            "django", "spring", "nodejs", "swift", "rust", "go"
        )
        techKeywords.forEach { tech ->
            if (lower.contains(tech)) {
                saveFact("tech_preference", "Kullandığı teknoloji: ${tech.capitalize()}", 0.7f)
            }
        }

        // Kullanıcı tercihleri (kısa/uzun cevap)
        if (lower.contains("kısa cevap") || lower.contains("özet ver") || lower.contains("kısaca")) {
            savePreference("response_style", "short")
        }
        if (lower.contains("detaylı") || lower.contains("ayrıntılı") || lower.contains("açıkla")) {
            savePreference("response_style", "detailed")
        }

        // Düzeltme algılama
        if (lower.contains("hayır, demek istediğim") ||
            lower.contains("yanlış anladın") ||
            lower.contains("seni düzelteyim") ||
            lower.contains("aslında")) {
            saveFact("correction_signal", "Kullanıcı zaman zaman düzeltme yapıyor", 0.9f)
        }
    }

    private suspend fun trackQueryPattern(message: String, mode: String) {
        // Mesajı anahtar kelimelere indirge
        val keywords = message.lowercase()
            .replace(Regex("[^a-zA-ZçğıöşüÇĞİÖŞÜ ]"), " ")
            .split(" ")
            .filter { it.length > 3 }
            .take(3)
            .joinToString(" ")

        if (keywords.isBlank()) return

        val existing = queryPatternDao.findPattern(keywords, mode)
        if (existing != null) {
            queryPatternDao.incrementFrequency(existing.id)
        } else {
            queryPatternDao.insert(QueryPatternEntity(pattern = keywords, mode = mode))
        }
    }

    // ─── Dinamik Sistem Promptu ───────────────────────────────────────────────

    suspend fun buildDynamicSystemPrompt(basePrompt: String): String {
        return withContext(Dispatchers.IO) {
            val sb = StringBuilder(basePrompt)
            sb.append("\n\n--- KULLANICI HAKKINDA ÖĞRENİLENLER ---\n")

            // Kullanıcı adı
            val userName = userPreferenceDao.get("user_name")?.value
            if (userName != null) {
                sb.append("• Kullanıcının adı: $userName. Onu adıyla hitap edebilirsin.\n")
            }

            // Meslek
            val profession = userPreferenceDao.get("profession")?.value
            if (profession != null) {
                sb.append("• Mesleği: $profession. Cevapları buna göre uyarla.\n")
            }

            // Cevap stili
            val responseStyle = userPreferenceDao.get("response_style")?.value
            when (responseStyle) {
                "short" -> sb.append("• Kullanıcı kısa ve öz cevaplar istiyor.\n")
                "detailed" -> sb.append("• Kullanıcı detaylı açıklamalar istiyor.\n")
            }

            // Öğrenilen gerçekler
            val facts = learnedFactDao.getTopFacts(10)
            if (facts.isNotEmpty()) {
                sb.append("• Diğer bilgiler:\n")
                facts.filter { it.category !in listOf("user_name", "profession") }
                    .take(5)
                    .forEach { sb.append("  - ${it.fact}\n") }
            }

            // Son konuşmalardan bağlam
            val recentConvs = conversationDao.getLastN(6)
            if (recentConvs.isNotEmpty()) {
                sb.append("\n--- SON KONUŞMA BAĞLAMI ---\n")
                sb.append("(Kullanıcı daha önce bu konuları konuştu - bağlamı koru)\n")
                recentConvs.reversed().forEach { conv ->
                    val role = if (conv.role == "user") "Kullanıcı" else "Sen"
                    val preview = conv.content.take(100)
                    sb.append("[$role]: $preview${if (conv.content.length > 100) "..." else ""}\n")
                }
            }

            // Sık kullanılan konular
            val topPatterns = queryPatternDao.getTopPatterns(5)
            if (topPatterns.any { it.frequency > 1 }) {
                sb.append("\n--- SIK SORULAN KONULAR ---\n")
                topPatterns.filter { it.frequency > 1 }.forEach {
                    sb.append("• ${it.pattern} (${it.frequency} kez, mod: ${it.mode})\n")
                }
            }

            // Düzeltmeler
            val corrections = correctionDao.getRecent(3)
            if (corrections.isNotEmpty()) {
                sb.append("\n--- HATIRLA: DÜZELTMELER ---\n")
                corrections.forEach { c ->
                    sb.append("• Kullanıcı şunu düzeltti: '${c.originalQuery.take(50)}'\n")
                    sb.append("  Doğru cevap: '${c.correctedResponse.take(100)}'\n")
                }
            }

            sb.append("\n--- ÖZ ÖĞRENME AKTİF ---\n")
            sb.append("Konuşma boyunca kullanıcı hakkında yeni bilgiler öğrenmeye devam et.\n")

            sb.toString()
        }
    }

    // ─── Yardımcı metodlar ───────────────────────────────────────────────────

    private suspend fun saveFact(category: String, fact: String, confidence: Float) {
        val existing = learnedFactDao.getByCategory(category)
            .firstOrNull { it.fact == fact }
        if (existing != null) {
            learnedFactDao.incrementUsage(existing.id)
        } else {
            learnedFactDao.insert(
                LearnedFactEntity(
                    category = category,
                    fact = fact,
                    confidence = confidence
                )
            )
        }
    }

    private suspend fun savePreference(key: String, value: String) {
        userPreferenceDao.upsert(UserPreferenceEntity(key = key, value = value))
    }

    suspend fun saveCorrection(originalQuery: String, wrongResponse: String, correctedResponse: String) {
        correctionDao.insert(
            CorrectionEntity(
                originalQuery = originalQuery,
                wrongResponse = wrongResponse,
                correctedResponse = correctedResponse
            )
        )
        saveFact("correction", "Düzeltme: $correctedResponse", 1.0f)
    }

    suspend fun getUserName(): String? {
        return userPreferenceDao.get("user_name")?.value
    }

    suspend fun getLearningStats(): LearningStats {
        return withContext(Dispatchers.IO) {
            LearningStats(
                totalConversations = conversationDao.getCount(),
                learnedFacts = learnedFactDao.getAll().size,
                topPatterns = queryPatternDao.getTopPatterns(3).map { it.pattern },
                userName = userPreferenceDao.get("user_name")?.value,
                profession = userPreferenceDao.get("profession")?.value
            )
        }
    }
}

data class LearningStats(
    val totalConversations: Int,
    val learnedFacts: Int,
    val topPatterns: List<String>,
    val userName: String?,
    val profession: String?
)