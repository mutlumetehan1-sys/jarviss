package com.jarvis.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// JARVIS Renk Paleti
val CyanPrimary    = Color(0xFF00D4FF)
val BluePrimary    = Color(0xFF0066FF)
val DarkBackground = Color(0xFF020B18)
val PanelBg        = Color(0xFF001428)
val GreenAccent    = Color(0xFF00FF88)
val RedAccent      = Color(0xFFFF3333)
val UserMsgBg      = Color(0xFF001A3D)
val AiMsgBg        = Color(0xFF000D1F)
val BorderColor    = Color(0x3300D4FF)
val TextDim        = Color(0x8800D4FF)

private val JarvisColorScheme = darkColorScheme(
    primary           = CyanPrimary,
    onPrimary         = DarkBackground,
    secondary         = BluePrimary,
    onSecondary       = Color.White,
    background        = DarkBackground,
    onBackground      = CyanPrimary,
    surface           = PanelBg,
    onSurface         = CyanPrimary,
    error             = RedAccent,
    onError           = Color.White,
    outline           = BorderColor
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        content = content
    )
}