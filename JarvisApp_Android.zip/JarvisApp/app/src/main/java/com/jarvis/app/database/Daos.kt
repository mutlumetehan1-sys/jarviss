package com.jarvis.app.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(conversation: ConversationEntity): Long

    @Query("SELECT * FROM conversations WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    suspend fun getBySession(sessionId: String): List<ConversationEntity>

    @Query("SELECT * FROM conversations ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecent(limit: Int = 50): List<ConversationEntity>

    @Query("SELECT * FROM conversations ORDER BY timestamp DESC")
    fun getAllFlow(): Flow<List<ConversationEntity>>

    @Query("SELECT DISTINCT sessionId FROM conversations ORDER BY MAX(timestamp) DESC LIMIT :limit")
    suspend fun getRecentSessions(limit: Int = 10): List<String>

    @Query("DELETE FROM conversations WHERE sessionId = :sessionId")
    suspend fun deleteSession(sessionId: String)

    @Query("DELETE FROM conversations")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM conversations")
    suspend fun getCount(): Int

    // Son N konuşmayı API context'i için getir
    @Query("SELECT * FROM conversations ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getLastN(limit: Int): List<ConversationEntity>
}

@Dao
interface UserPreferenceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(pref: UserPreferenceEntity)

    @Query("SELECT * FROM user_preferences WHERE `key` = :key")
    suspend fun get(key: String): UserPreferenceEntity?

    @Query("SELECT * FROM user_preferences")
    suspend fun getAll(): List<UserPreferenceEntity>

    @Query("DELETE FROM user_preferences WHERE `key` = :key")
    suspend fun delete(key: String)
}

@Dao
interface LearnedFactDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(fact: LearnedFactEntity): Long

    @Query("SELECT * FROM learned_facts ORDER BY usageCount DESC")
    suspend fun getAll(): List<LearnedFactEntity>

    @Query("SELECT * FROM learned_facts WHERE category = :category")
    suspend fun getByCategory(category: String): List<LearnedFactEntity>

    @Update
    suspend fun update(fact: LearnedFactEntity)

    @Query("UPDATE learned_facts SET usageCount = usageCount + 1, updatedAt = :now WHERE id = :id")
    suspend fun incrementUsage(id: Long, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM learned_facts WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM learned_facts ORDER BY usageCount DESC LIMIT :limit")
    suspend fun getTopFacts(limit: Int = 20): List<LearnedFactEntity>
}

@Dao
interface QueryPatternDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(pattern: QueryPatternEntity): Long

    @Query("SELECT * FROM query_patterns WHERE pattern = :pattern AND mode = :mode LIMIT 1")
    suspend fun findPattern(pattern: String, mode: String): QueryPatternEntity?

    @Query("UPDATE query_patterns SET frequency = frequency + 1, lastUsed = :now WHERE id = :id")
    suspend fun incrementFrequency(id: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM query_patterns ORDER BY frequency DESC LIMIT :limit")
    suspend fun getTopPatterns(limit: Int = 10): List<QueryPatternEntity>
}

@Dao
interface CorrectionDao {
    @Insert
    suspend fun insert(correction: CorrectionEntity): Long

    @Query("SELECT * FROM corrections ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecent(limit: Int = 10): List<CorrectionEntity>
}