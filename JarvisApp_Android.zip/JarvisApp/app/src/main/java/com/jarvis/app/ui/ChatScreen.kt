package com.jarvis.app.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.app.ui.theme.*
import com.jarvis.app.viewmodel.ChatMessage
import com.jarvis.app.viewmodel.ChatMode
import com.jarvis.app.viewmodel.JarvisUiState

@Composable
fun ChatScreen(
    uiState: JarvisUiState,
    onSend: () -> Unit,
    onInputChange: (String) -> Unit,
    onModeChange: (ChatMode) -> Unit,
    onMicToggle: () -> Unit,
    onTtsToggle: () -> Unit,
    onClearHistory: () -> Unit,
    onToggleLearning: () -> Unit,
    onResetApi: () -> Unit,
    isSpeechAvailable: Boolean
) {
    val listState = rememberLazyListState()

    // Yeni mesaj gelince otomatik kaydır
    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // ── Header ──────────────────────────────────────────────────────────
        JarvisHeader(
            mode = uiState.currentMode,
            isSpeaking = uiState.isSpeaking,
            ttsEnabled = uiState.ttsEnabled,
            onTtsToggle = onTtsToggle,
            onClearHistory = onClearHistory,
            onToggleLearning = onToggleLearning,
            onResetApi = onResetApi
        )

        // ── Mod Sekmeleri ────────────────────────────────────────────────────
        ModeTabRow(
            currentMode = uiState.currentMode,
            onModeChange = onModeChange
        )

        // ── Öğrenme Paneli (açılır) ──────────────────────────────────────────
        AnimatedVisibility(
            visible = uiState.showLearningPanel,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            LearningPanel(stats = uiState.learningStats)
        }

        // ── Mesaj Listesi ────────────────────────────────────────────────────
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(uiState.messages, key = { it.id }) { msg ->
                AnimatedVisibility(
                    visible = true,
                    enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn()
                ) {
                    MessageBubble(message = msg)
                }
            }

            // Yükleniyor göstergesi
            if (uiState.isLoading) {
                item {
                    ThinkingIndicator()
                }
            }
        }

        // ── Hata Mesajı ──────────────────────────────────────────────────────
        uiState.errorMessage?.let { err ->
            Text(
                text = "⚠ $err",
                color = RedAccent,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x22FF3333))
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                textAlign = TextAlign.Center
            )
        }

        // ── Konuşuyor Göstergesi ─────────────────────────────────────────────
        AnimatedVisibility(visible = uiState.isSpeaking) {
            SpeakingIndicator()
        }

        // ── Dinleniyor Göstergesi ────────────────────────────────────────────
        AnimatedVisibility(visible = uiState.isListening) {
            ListeningIndicator()
        }

        // ── Giriş Alanı ──────────────────────────────────────────────────────
        InputArea(
            text = uiState.inputText,
            onTextChange = onInputChange,
            onSend = onSend,
            onMicToggle = onMicToggle,
            isListening = uiState.isListening,
            isLoading = uiState.isLoading,
            isSpeechAvailable = isSpeechAvailable
        )
    }
}

// ─── Header ──────────────────────────────────────────────────────────────────

@Composable
fun JarvisHeader(
    mode: ChatMode,
    isSpeaking: Boolean,
    ttsEnabled: Boolean,
    onTtsToggle: () -> Unit,
    onClearHistory: () -> Unit,
    onToggleLearning: () -> Unit,
    onResetApi: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "dot")
    val dotAlpha by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 0.3f,
        animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Reverse),
        label = "dot_alpha"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelBg)
            .border(BorderValues.bottom, BorderColor)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Logo
        Text(
            text = "J.A.R.V.I.S",
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            color = CyanPrimary,
            letterSpacing = 5.sp
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Aktif mod etiketi
            Text(
                text = mode.label,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim,
                letterSpacing = 2.sp
            )

            // TTS butonu
            IconButton(
                onClick = onTtsToggle,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = if (ttsEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    contentDescription = "TTS",
                    tint = if (ttsEnabled) CyanPrimary else TextDim,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Öğrenme paneli
            IconButton(
                onClick = onToggleLearning,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Psychology,
                    contentDescription = "Öğrenme",
                    tint = GreenAccent,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Geçmişi temizle
            IconButton(
                onClick = onClearHistory,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Temizle",
                    tint = TextDim,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Durum noktası
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (isSpeaking) GreenAccent else GreenAccent)
                    .alpha(if (isSpeaking) dotAlpha else dotAlpha)
            )
        }
    }
}

val BorderValues = object {
    val bottom get() = androidx.compose.foundation.layout.PaddingValues(bottom = 1.dp)
}

// ─── Mod Sekmeleri ────────────────────────────────────────────────────────────

@Composable
fun ModeTabRow(
    currentMode: ChatMode,
    onModeChange: (ChatMode) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelBg)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        ChatMode.entries.forEach { mode ->
            val isActive = mode == currentMode
            OutlinedButton(
                onClick = { onModeChange(mode) },
                modifier = Modifier.weight(1f).height(32.dp),
                shape = RoundedCornerShape(2.dp),
                contentPadding = PaddingValues(0.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = if (isActive) Color(0x1400D4FF) else Color.Transparent,
                    contentColor = if (isActive) CyanPrimary else TextDim
                ),
                border = BorderStroke(
                    1.dp,
                    if (isActive) CyanPrimary else BorderColor
                )
            ) {
                Text(
                    text = mode.label,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

// ─── Öğrenme Paneli ───────────────────────────────────────────────────────────

@Composable
fun LearningPanel(stats: com.jarvis.app.learning.LearningStats?) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF001020))
            .border(BorderStroke(1.dp, Color(0x2200FF88)))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "◆ JARVIS ÖĞRENME RAPORU ◆",
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = GreenAccent,
            letterSpacing = 2.sp
        )
        HorizontalDivider(color = Color(0x2200FF88))

        if (stats != null) {
            LearningStatRow("Toplam Konuşma", "${stats.totalConversations}")
            LearningStatRow("Öğrenilen Gerçek", "${stats.learnedFacts}")
            stats.userName?.let { LearningStatRow("Kullanıcı Adı", it) }
            stats.profession?.let { LearningStatRow("Meslek", it) }
            if (stats.topPatterns.isNotEmpty()) {
                LearningStatRow("Sık Konular", stats.topPatterns.take(2).joinToString(", "))
            }
        } else {
            Text("Henüz veri yok.", fontSize = 10.sp, color = TextDim, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun LearningStatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 10.sp, color = TextDim, fontFamily = FontFamily.Monospace)
        Text(value, fontSize = 10.sp, color = GreenAccent, fontFamily = FontFamily.Monospace)
    }
}

// ─── Mesaj Balonu ─────────────────────────────────────────────────────────────

@Composable
fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == "user"

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        // Etiket
        Text(
            text = if (isUser) "SİZ" else "JARVIS",
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace,
            color = TextDim,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )

        // Balon
        Box(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .background(
                    color = if (isUser) UserMsgBg else AiMsgBg,
                    shape = RoundedCornerShape(2.dp)
                )
                .border(
                    1.dp,
                    if (isUser) Color(0x660066FF) else BorderColor,
                    RoundedCornerShape(2.dp)
                )
                .padding(10.dp)
        ) {
            // Kod blokları varsa ayrı render et
            MessageContent(content = message.content, isUser = isUser)
        }
    }
}

@Composable
fun MessageContent(content: String, isUser: Boolean) {
    val codeBlockRegex = Regex("```[\\s\\S]*?```")
    val parts = codeBlockRegex.split(content)
    val codeBlocks = codeBlockRegex.findAll(content).map { it.value }.toList()

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        parts.forEachIndexed { index, part ->
            if (part.isNotBlank()) {
                Text(
                    text = part.trim(),
                    fontSize = 13.sp,
                    color = if (isUser) Color(0xFF88AAFF) else CyanPrimary,
                    fontFamily = FontFamily.SansSerif,
                    lineHeight = 20.sp
                )
            }
            if (index < codeBlocks.size) {
                CodeBlock(code = codeBlocks[index]
                    .replace(Regex("```\\w*\\n?"), "")
                    .replace("```", "")
                    .trim()
                )
            }
        }
    }
}

@Composable
fun CodeBlock(code: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF000000), RoundedCornerShape(2.dp))
            .border(1.dp, Color(0x1A00D4FF), RoundedCornerShape(2.dp))
            .padding(10.dp)
            .horizontalScroll(rememberScrollState())
    ) {
        Text(
            text = code,
            fontSize = 11.sp,
            color = GreenAccent,
            fontFamily = FontFamily.Monospace,
            lineHeight = 16.sp
        )
    }
}

// ─── Düşünüyor Göstergesi ─────────────────────────────────────────────────────

@Composable
fun ThinkingIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "think")

    Row(
        modifier = Modifier
            .padding(vertical = 4.dp)
            .background(Color(0xFF000D1F), RoundedCornerShape(2.dp))
            .border(1.dp, BorderColor, RoundedCornerShape(2.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        repeat(3) { index ->
            val dotAlpha by infiniteTransition.animateFloat(
                initialValue = 0.2f, targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(600, delayMillis = index * 200),
                    repeatMode = RepeatMode.Reverse
                ), label = "dot$index"
            )
            val dotScale by infiniteTransition.animateFloat(
                initialValue = 0.8f, targetValue = 1.2f,
                animationSpec = infiniteRepeatable(
                    animation = tween(600, delayMillis = index * 200),
                    repeatMode = RepeatMode.Reverse
                ), label = "scale$index"
            )
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .scale(dotScale)
                    .alpha(dotAlpha)
                    .clip(CircleShape)
                    .background(CyanPrimary)
            )
        }
    }
}

// ─── Konuşuyor Göstergesi ────────────────────────────────────────────────────

@Composable
fun SpeakingIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "speaking")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 0.3f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "speak_alpha"
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0x11000000))
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.alpha(alpha)
        ) {
            Icon(Icons.Default.VolumeUp, null, tint = GreenAccent, modifier = Modifier.size(14.dp))
            Text("◆ KONUŞUYOR ◆", fontSize = 9.sp, color = GreenAccent,
                fontFamily = FontFamily.Monospace, letterSpacing = 2.sp)
        }
    }
}

// ─── Dinleniyor Göstergesi ───────────────────────────────────────────────────

@Composable
fun ListeningIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "listening")

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0x22FF3333))
            .padding(6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Ses dalgaları
            repeat(5) { index ->
                val heights = listOf(6f, 14f, 20f, 14f, 6f)
                val barHeight by infiniteTransition.animateFloat(
                    initialValue = heights[index] * 0.4f,
                    targetValue = heights[index],
                    animationSpec = infiniteRepeatable(
                        animation = tween(400, delayMillis = index * 80),
                        repeatMode = RepeatMode.Reverse
                    ), label = "bar$index"
                )
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .height(barHeight.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(RedAccent)
                )
            }
            Spacer(Modifier.width(4.dp))
            Text("DİNLİYOR...", fontSize = 9.sp, color = RedAccent,
                fontFamily = FontFamily.Monospace, letterSpacing = 2.sp)
        }
    }
}

// ─── Giriş Alanı ─────────────────────────────────────────────────────────────

@Composable
fun InputArea(
    text: String,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    onMicToggle: () -> Unit,
    isListening: Boolean,
    isLoading: Boolean,
    isSpeechAvailable: Boolean
) {
    val micScale by animateFloatAsState(
        targetValue = if (isListening) 1.15f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "mic_scale"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelBg)
            .border(BorderStroke(1.dp, BorderColor))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Mikrofon butonu
        if (isSpeechAvailable) {
            IconButton(
                onClick = onMicToggle,
                modifier = Modifier
                    .size(42.dp)
                    .scale(micScale)
                    .clip(CircleShape)
                    .background(
                        if (isListening) Color(0x22FF3333) else Color.Transparent
                    )
                    .border(
                        2.dp,
                        if (isListening) RedAccent else CyanPrimary,
                        CircleShape
                    )
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Mikrofon",
                    tint = if (isListening) RedAccent else CyanPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Metin girişi
        OutlinedTextField(
            value = text,
            onValueChange = onTextChange,
            modifier = Modifier
                .weight(1f)
                .heightIn(min = 42.dp, max = 120.dp),
            placeholder = {
                Text(
                    "Mesaj yaz${if (isSpeechAvailable) " veya mikrofona bas" else ""}...",
                    color = TextDim,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = CyanPrimary,
                unfocusedTextColor = CyanPrimary,
                cursorColor = CyanPrimary,
                focusedBorderColor = CyanPrimary,
                unfocusedBorderColor = BorderColor,
                focusedContainerColor = AiMsgBg,
                unfocusedContainerColor = AiMsgBg
            ),
            textStyle = LocalTextStyle.current.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() }),
            shape = RoundedCornerShape(2.dp),
            maxLines = 5
        )

        // Gönder butonu
        IconButton(
            onClick = onSend,
            enabled = text.isNotBlank() && !isLoading,
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(
                    if (text.isNotBlank() && !isLoading)
                        Color(0x1400D4FF) else Color.Transparent
                )
                .border(
                    1.dp,
                    if (text.isNotBlank() && !isLoading) CyanPrimary else BorderColor,
                    RoundedCornerShape(2.dp)
                )
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = CyanPrimary,
                    strokeWidth = 2.dp
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Gönder",
                    tint = if (text.isNotBlank()) CyanPrimary else TextDim,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}