package com.jarvis.app.api

import com.google.gson.annotations.SerializedName

data class AnthropicRequest(
    val model: String = "claude-sonnet-4-20250514",
    @SerializedName("max_tokens") val maxTokens: Int = 1500,
    val system: String,
    val messages: List<ApiMessage>
)

data class ApiMessage(
    val role: String,
    val content: String
)

data class AnthropicResponse(
    val id: String?,
    val type: String?,
    val role: String?,
    val content: List<ContentBlock>?,
    val model: String?,
    val error: ApiError?
)

data class ContentBlock(
    val type: String,
    val text: String
)

data class ApiError(
    val type: String,
    val message: String
)