package com.jarvis.app.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.app.ui.theme.*

@Composable
fun SetupScreen(
    onInit: (String) -> Unit,
    errorMessage: String?
) {
    var apiKey by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    // Logo animasyonu
    val infiniteTransition = rememberInfiniteTransition(label = "logo")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.6f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ), label = "alpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentAlignment = Alignment.Center
    ) {
        // Arka plan grid efekti
        GridBackground()

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Logo
            Text(
                text = "J.A.R.V.I.S",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = CyanPrimary,
                letterSpacing = 8.sp,
                modifier = Modifier.alpha(alpha)
            )

            Text(
                text = "JUST A RATHER VERY INTELLIGENT SYSTEM",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Dekoratif çizgi
            HorizontalDivider(
                modifier = Modifier.fillMaxWidth(0.6f),
                color = BorderColor
            )

            Text(
                text = "◆ API ANAHTARI GEREKLİ ◆",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = CyanPrimary,
                letterSpacing = 3.sp
            )

            // API Key girişi
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, if (apiKey.startsWith("sk-ant")) GreenAccent else BorderColor,
                        RoundedCornerShape(2.dp)),
                placeholder = {
                    Text("sk-ant-api...", color = TextDim, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None
                                       else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { onInit(apiKey) }),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Default.VisibilityOff
                                          else Icons.Default.Visibility,
                            contentDescription = null,
                            tint = TextDim
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = CyanPrimary,
                    unfocusedTextColor = CyanPrimary,
                    cursorColor = CyanPrimary,
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = AiMsgBg,
                    unfocusedContainerColor = AiMsgBg
                ),
                textStyle = LocalTextStyle.current.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                ),
                singleLine = true,
                shape = RoundedCornerShape(2.dp)
            )

            // Hata mesajı
            errorMessage?.let {
                Text(
                    text = "⚠ $it",
                    color = RedAccent,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center
                )
            }

            // Başlat butonu
            Button(
                onClick = { onInit(apiKey) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    contentColor = CyanPrimary
                ),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = Brush.horizontalGradient(listOf(CyanPrimary, BluePrimary))
                )
            ) {
                Text(
                    "BAŞLAT",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 4.sp,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Anthropic Claude API anahtarınızı girin.\nAnahtar cihazınızda güvenli şekilde saklanır.",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim,
                textAlign = TextAlign.Center,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
fun GridBackground() {
    // Canvas grid çizimi basit Box ile simüle
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0x0500D4FF),
                        Color.Transparent
                    )
                )
            )
    )
}